VERSION = (0, 1)
DAEMON_MAIN = 'accio'


def get_package_version():
    return '%s.%s' % (VERSION[0], VERSION[1])
